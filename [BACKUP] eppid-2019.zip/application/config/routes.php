<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Home';
$route['page/dasar-hukum-ppid'] = 'page/dasar_hukum';
$route['page/standar-layanan'] = 'page/standar_layanan';



$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
