<div class="col-sm-3">
	<div class="row">
		<div class="content-title"><i class="fa fa-bullhorn "></i> Standar Layanan</div>
		<div class="list-item-2">
		    <ul class="content-container"> 
		        <li><a href="<?= base_url()?>page/biaya-media-waktu"><i class="fa fa-caret-right"></i> Biaya, Media, Waktu Pelayanan</a></li>
		        <li><a href="<?= base_url()?>data-info-sda/daerah-irigasi"><i class="fa fa-caret-right"></i> Prosedur Permohonan Informasi</a></li>
		        <li><a href="<?= base_url()?>data-info-sda/daerah-irigasi"><i class="fa fa-caret-right"></i> Prosedur pengajuan Keberatan</a></li>
		        <li><a href="<?= base_url()?>data-info-sda/daerah-irigasi"><i class="fa fa-caret-right"></i> Prosedur Sengketa Informasi</a></li>
		    </ul>
		</div>		
	</div>
</div>
